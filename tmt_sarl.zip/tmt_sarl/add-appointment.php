<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Configuration de la base de données
$host = "localhost";
$user = "root";
$password = ""; // Par défaut, il n'y a pas de mot de passe sur XAMPP
$dbname = "rendez_vous"; // Remplacez par le nom de votre base de données

// Connexion à la base de données
$conn = new mysqli($host, $user, $password, $dbname);

// Vérification de la connexion
if ($conn->connect_error) {
    die("Connexion échouée : " . $conn->connect_error);
}

// Assurez-vous que les données sont envoyées via POST en JSON
header('Content-Type: application/json');  // Spécifie que la réponse est en JSON

// Récupération des données POST
$data = json_decode(file_get_contents("php://input"), true);

// Récupérer les créneaux réservés pour une date spécifique
$date = $_POST['date']; // La date envoyée par le client
$sql = "SELECT time FROM appointments WHERE date = '$date'";
$result = $conn->query($sql);

$reservedSlots = [];
while($row = $result->fetch_assoc()) {
    $reservedSlots[] = $row['time'];
}

echo json_encode($reservedSlots); // Retourner les créneaux réservés
// Validation des données reçues
if (!isset($data['name']) || !isset($data['email']) || !isset($data['reason']) || !isset($data['date']) || !isset($data['time'])) {
    echo json_encode(["message" => "Erreur : données manquantes"]);
    exit();
}

$name = $data['name'];
$email = $data['email'];
$reason = $data['reason'];
$date = $data['date'];
$time = $data['time'];

// Préparation de la requête SQL pour éviter les injections SQL
$stmt = $conn->prepare("INSERT INTO appointments (name, email, reason, date, time) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("sssss", $name, $email, $reason, $date, $time);

// Exécution de la requête
if ($stmt->execute()) {
    echo json_encode(["message" => "Données insérées avec succès"]);
} else {
    // Journalisation des erreurs dans un fichier
    error_log("Erreur lors de l'insertion dans la base de données : " . $stmt->error);
    echo json_encode(["message" => "Erreur : " . $stmt->error]);
}

// Fermeture de la connexion
$stmt->close();
$conn->close();
?>
