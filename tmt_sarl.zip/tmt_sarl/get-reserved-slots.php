<?php
// Connexion à la base de données
$conn = new mysqli("localhost", "username", "password", "database");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$data = json_decode(file_get_contents("php://input"), true);
$date = $data['date'];

$sql = "SELECT time FROM appointments WHERE date = '$date'";
$result = $conn->query($sql);

$reservedSlots = [];
while ($row = $result->fetch_assoc()) {
    $reservedSlots[] = $row['time'];
}

echo json_encode($reservedSlots);
?>
