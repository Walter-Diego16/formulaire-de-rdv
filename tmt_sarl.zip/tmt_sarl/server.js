const express = require("express");
const mysql = require("mysql2");
const bodyParser = require("body-parser");
const cors = require("cors");

const app = express();

// Configuration de la connexion MySQL
const db = mysql.createConnection({
    host: "localhost", // Hôte local
    user: "root", // Utilisateur par défaut de XAMPP
    password: "", // Mot de passe vide par défaut
    database: "rendez_vous", // Base de données créée dans phpMyAdmin
});

// Tester la connexion à la base de données
db.connect((err) => {
    if (err) {
        console.error("Erreur de connexion à MySQL :", err);
    } else {
        console.log("Connecté à la base de données MySQL !");
    }
});

app.use(cors());
app.use(bodyParser.json());

// Endpoint pour enregistrer un rendez-vous
app.post("/add-appointment", (req, res) => {
    const { name, email, reason, date, time } = req.body;

    // Requête pour insérer un rendez-vous
    const query = `
        INSERT INTO appointments (name, email, reason, date, time)
        VALUES (?, ?, ?, ?, ?)
    `;

    db.query(query, [name, email, reason, date, time], (err, result) => {
        if (err) {
            console.error("Erreur lors de l'enregistrement :", err);
            res.status(500).json({ error: "Erreur serveur" });
        } else {
            res.status(200).json({ message: "Rendez-vous enregistré avec succès !" });
        }
    });
});

// Démarrer le serveur
app.listen(3000, () => console.log("Serveur backend en écoute sur le port 3000"));
