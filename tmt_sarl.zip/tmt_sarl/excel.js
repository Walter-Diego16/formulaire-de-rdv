// Fonction pour exporter les données du rendez-vous dans un fichier Excel
function exportToExcel(data) {
    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Rendez-vous");

    // Téléchargement du fichier Excel
    XLSX.writeFile(workbook, "rendez_vous_tmt_sarl.xlsx");
}

// Capturer et exporter les données
form.addEventListener("submit", (event) => {
    event.preventDefault();
    const name = form.name.value;
    const email = form.email.value;
    const reason = form.reason.value;
    const date = form.date.value;
    const timeSlot = document.querySelector(".time-slot.active")?.innerText;

    if (!timeSlot) {
        alert("Veuillez sélectionner un créneau horaire !");
        return;
    }

    // Préparer les données pour Excel
    const appointmentData = [
        {
            Nom: name,
            Email: email,
            Motif: reason,
            Date: date,
            Heure: timeSlot,
        },
    ];

    // Exporter les données dans un fichier Excel
    exportToExcel(appointmentData);

    alert(`Rendez-vous confirmé pour ${name} le ${date} à ${timeSlot}.`);
    form.reset();
    displayTimeSlots(); // Réinitialiser les créneaux
});
