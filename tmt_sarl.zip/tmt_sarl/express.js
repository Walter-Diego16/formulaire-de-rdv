app.post("/add-appointment", (req, res) => {
    const { name, email, reason, date, time } = req.body;
    db.run(
        "INSERT INTO appointments (name, email, reason, date, time) VALUES (?, ?, ?, ?, ?)",
        [name, email, reason, date, time],
        function (err) {
            if (err) {
                res.status(500).json({ error: err.message });
            } else {
                res.status(200).json({ message: "Rendez-vous enregistré avec succès !" });
            }
        }
    );
});
